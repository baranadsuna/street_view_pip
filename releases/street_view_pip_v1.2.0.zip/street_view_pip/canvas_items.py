# -*- coding: utf-8 -*-
"""
QGIS Map Canvas Overlays with Smooth Pose Interpolation, Walk/Run, Lifted Grab & 30s Wave.

Features:
  - Eyeless golden-yellow Pegman with dark outline & terracotta scarf (matching Image 6).
  - Direct on-canvas grab ("held by one arm / collar"): user can pick Pegman up
    directly from the map canvas and drop it onto any new street.
  - Smooth ~33 FPS ease-out interpolation of position, heading, and FOV cone.
  - Distance-aware gait: walking stride for nearby steps (<= 28m) and dynamic
    forward-leaning sprint/run animation with speed trails for far jumps (> 28m).
  - Idle wave animation triggered automatically after 30 seconds stationary.
"""

import math
import time
from typing import Optional

from qgis.PyQt import QtCore, QtGui
from qgis.core import QgsGeometry, QgsPointXY
from qgis.gui import QgsMapCanvas, QgsMapCanvasItem, QgsRubberBand

from .geo_utils import build_fov_cone_polygon, geodesic_distance_m, wgs84_to_canvas
from .qt_compat import (
    ANTIALIASING,
    BRUSH_SOLID,
    GEOM_LINE,
    GEOM_POLYGON,
    NO_PEN,
    PEN_DASH,
    PEN_SOLID,
)

IDLE_WAVE_DELAY_SEC = 30.0
IDLE_WAVE_DURATION_SEC = 4.5
IDLE_WAVE_REPEAT_SEC = 12.0
RUN_DISTANCE_THRESHOLD_M = 28.0


class PegmanCanvasMarker(QgsMapCanvasItem):
    """Expressive eyeless yellow Pegman supporting look-turn, walk, run, lift-grab & 30s wave."""

    def __init__(self, canvas: QgsMapCanvas):
        super().__init__(canvas)
        self._canvas = canvas
        self._map_point: Optional[QgsPointXY] = None
        self._heading: float = 0.0
        self._turn_velocity: float = 0.0
        self._walk_phase: float = 0.0
        self._walk_amount: float = 0.0
        self._running: bool = False
        self._lifted: bool = False
        self._dangle_tilt: float = 0.0
        self._waving: bool = False
        self._wave_phase: float = 0.0
        self._visible_marker: bool = False
        self.setZValue(120)

    def set_pose(
        self,
        map_point: QgsPointXY,
        heading: float = 0.0,
        turn_velocity: float = 0.0,
        walk_phase: float = 0.0,
        walk_amount: float = 0.0,
        running: bool = False,
        lifted: bool = False,
        dangle_tilt: float = 0.0,
        waving: bool = False,
        wave_phase: float = 0.0,
    ) -> None:
        self._map_point = QgsPointXY(map_point)
        self._heading = float(heading) % 360.0
        self._turn_velocity = max(-1.0, min(1.0, float(turn_velocity)))
        self._walk_phase = float(walk_phase)
        self._walk_amount = max(0.0, min(1.0, float(walk_amount)))
        self._running = bool(running)
        self._lifted = bool(lifted)
        self._dangle_tilt = max(-22.0, min(22.0, float(dangle_tilt)))
        self._waving = bool(waving)
        self._wave_phase = float(wave_phase)
        self._visible_marker = True
        self.setPos(self.toCanvasCoordinates(self._map_point))
        self.show()
        self.update()

    def is_visible_marker(self) -> bool:
        return self._visible_marker

    def hit_test_canvas_point(self, viewport_pt: QtCore.QPointF) -> bool:
        """Return True if viewport_pt is directly over Pegman's body/head/arm."""
        if not self._visible_marker or self._map_point is None:
            return False
        anchor = self.toCanvasCoordinates(self._map_point)
        dx = viewport_pt.x() - anchor.x()
        dy = viewport_pt.y() - anchor.y()
        return (-19.0 <= dx <= 19.0) and (-42.0 <= dy <= 8.0)

    def clear(self) -> None:
        self._visible_marker = False
        self._map_point = None
        self._waving = False
        self._lifted = False
        self._running = False
        self.hide()

    def updatePosition(self) -> None:
        if self._visible_marker and self._map_point is not None:
            self.setPos(self.toCanvasCoordinates(self._map_point))

    def boundingRect(self) -> QtCore.QRectF:
        return QtCore.QRectF(-34.0, -48.0, 68.0, 60.0)

    def paint(self, painter: QtGui.QPainter, option=None, widget=None) -> None:
        if not self._visible_marker:
            return
        painter.save()
        painter.setRenderHint(ANTIALIASING, True)

        outline = QtGui.QPen(QtGui.QColor("#1e1b18"), 1.7, PEN_SOLID)
        gold_brush = QtGui.QBrush(QtGui.QColor("#facc15"), BRUSH_SOLID)
        gold_dark = QtGui.QBrush(QtGui.QColor("#eab308"), BRUSH_SOLID)
        scarf_brush = QtGui.QBrush(QtGui.QColor("#d9531e"), BRUSH_SOLID)

        # Ground anchor ring (suppressed while lifted in mid-air)
        if not self._lifted:
            painter.setPen(QtGui.QPen(QtGui.QColor("#0f172a"), 2.0, PEN_SOLID))
            painter.setBrush(QtGui.QBrush(QtGui.QColor(56, 189, 248, 225), BRUSH_SOLID))
            painter.drawEllipse(QtCore.QPointF(0.0, 0.0), 6.2, 6.2)

            painter.setPen(NO_PEN)
            painter.setBrush(QtGui.QBrush(QtGui.QColor(15, 23, 42, 95), BRUSH_SOLID))
            painter.drawEllipse(QtCore.QPointF(0.0, 0.2), 7.5, 2.4)

        # --- Special Pose 1: Held by Arm/Collar (Image 6 Dangling Pose!) ---
        if self._lifted:
            # Anchor raised hand near (0, -30) so cursor holds his raised arm/scruff
            painter.translate(2.0, -4.0)
            painter.rotate(14.0 + self._dangle_tilt)

            # Dangling legs
            painter.setPen(outline)
            painter.setBrush(gold_dark)
            painter.save()
            painter.translate(-2.4, -9.0)
            painter.rotate(10.0 + self._dangle_tilt * 0.4)
            painter.drawRoundedRect(QtCore.QRectF(-1.5, 0.0, 3.2, 8.8), 1.4, 1.4)
            painter.restore()
            painter.save()
            painter.translate(2.4, -9.0)
            painter.rotate(-8.0 + self._dangle_tilt * 0.4)
            painter.drawRoundedRect(QtCore.QRectF(-1.5, 0.0, 3.2, 8.8), 1.4, 1.4)
            painter.restore()

            # Torso
            painter.setBrush(gold_brush)
            torso = QtGui.QPainterPath()
            torso.moveTo(-6.8, -17.0)
            torso.quadTo(0.0, -19.8, 6.8, -17.0)
            torso.lineTo(5.8, -8.2)
            torso.lineTo(-5.8, -8.2)
            torso.closeSubpath()
            painter.drawPath(torso)

            # Orange neckerchief
            painter.setBrush(scarf_brush)
            scarf = QtGui.QPainterPath()
            scarf.moveTo(-4.8, -17.6)
            scarf.lineTo(4.8, -17.6)
            scarf.lineTo(0.0, -12.0)
            scarf.closeSubpath()
            painter.drawPath(scarf)

            # Left arm dangling loosely down
            painter.setBrush(gold_brush)
            painter.save()
            painter.translate(-6.4, -16.2)
            painter.rotate(12.0)
            painter.drawRoundedRect(QtCore.QRectF(-1.6, 0.0, 2.9, 8.2), 1.4, 1.4)
            painter.restore()

            # Right arm stretched straight UP where the user grabbed it!
            painter.save()
            painter.translate(5.6, -16.4)
            painter.rotate(-172.0)
            painter.drawRoundedRect(QtCore.QRectF(-1.5, 0.0, 3.0, 11.2), 1.4, 1.4)
            painter.restore()

            # Clean eyeless yellow head
            painter.drawEllipse(QtCore.QPointF(-0.5, -24.4), 5.3, 5.3)
            painter.restore()
            return

        # --- Normal Grounded Poses: Directional Look / Walk / Run / 30s Idle Wave ---
        if self._waving:
            dir_x, dir_y = 0.0, 1.0
            torso_scale_x = 1.0
            body_tilt = math.sin(self._wave_phase * 0.5) * 3.0
            head_shift_x = 0.0
            head_tilt = math.sin(self._wave_phase * 0.5) * 4.0
        else:
            rad = math.radians(self._heading)
            dir_x = math.sin(rad)
            dir_y = -math.cos(rad)
            torso_scale_x = 0.66 + 0.34 * abs(dir_y)
            sprint_lean = (dir_x * 13.0) if (self._running and self._walk_amount > 0.2) else 0.0
            body_tilt = self._turn_velocity * 4.5 + sprint_lean
            head_shift_x = dir_x * 2.5 + self._turn_velocity * 1.8
            head_tilt = self._turn_velocity * 9.0

        bounce_amp = 3.2 if self._running else 1.7
        bob_y = -abs(math.sin(self._walk_phase)) * bounce_amp * self._walk_amount

        # Speed trail streaks behind Pegman when running!
        if self._running and self._walk_amount > 0.25 and not self._waving:
            painter.save()
            trail_pen = QtGui.QPen(QtGui.QColor(56, 189, 248, 190), 1.8, PEN_SOLID)
            painter.setPen(trail_pen)
            tx = -dir_x * 11.0
            ty = -dir_y * 5.0 - 10.0
            painter.drawLine(QtCore.QPointF(tx, ty - 4.0), QtCore.QPointF(tx - dir_x * 7.0, ty - 4.0))
            painter.drawLine(QtCore.QPointF(tx, ty + 1.0), QtCore.QPointF(tx - dir_x * 9.0, ty + 1.0))
            painter.restore()

        painter.translate(0.0, bob_y)
        painter.rotate(body_tilt)

        # --- Legs (wide fast scissor stride when running, smooth stride when walking) ---
        painter.setPen(outline)
        painter.setBrush(gold_dark)
        leg_swing_deg = (math.sin(self._walk_phase) * (36.0 if self._running else 18.0)) * self._walk_amount
        leg_w = max(2.4, 3.0 * torso_scale_x)

        painter.save()
        painter.translate(-2.4 * torso_scale_x, -8.5)
        painter.rotate(leg_swing_deg)
        painter.drawRoundedRect(QtCore.QRectF(-leg_w * 0.5, 0.0, leg_w, 7.8), 1.3, 1.3)
        painter.restore()

        painter.save()
        painter.translate(2.4 * torso_scale_x, -8.5)
        painter.rotate(-leg_swing_deg)
        painter.drawRoundedRect(QtCore.QRectF(-leg_w * 0.5, 0.0, leg_w, 7.8), 1.3, 1.3)
        painter.restore()

        # --- Torso ---
        painter.setBrush(gold_brush)
        hw = 7.4 * torso_scale_x
        torso = QtGui.QPainterPath()
        torso.moveTo(-hw, -16.5)
        torso.quadTo(0.0, -19.5, hw, -16.5)
        torso.lineTo(hw * 0.86, -7.8)
        torso.lineTo(-hw * 0.86, -7.8)
        torso.closeSubpath()
        painter.drawPath(torso)

        # Orange neckerchief (shifts with look direction, hidden when facing straight North away)
        if dir_y > -0.45 or self._waving:
            painter.setBrush(scarf_brush)
            sx = 0.0 if self._waving else dir_x * 2.1
            sw = 4.6 * torso_scale_x
            scarf = QtGui.QPainterPath()
            scarf.moveTo(sx - sw, -17.2)
            scarf.lineTo(sx + sw, -17.2)
            scarf.lineTo(sx, -11.8)
            scarf.closeSubpath()
            painter.drawPath(scarf)

        # --- Arms (Normal walk, fast sprint pump, OR 30s Idle Wave) ---
        painter.setBrush(gold_brush)
        if self._waving:
            painter.drawRoundedRect(QtCore.QRectF(-hw - 2.6, -16.2, 2.8, 7.5), 1.3, 1.3)
            painter.save()
            painter.translate(hw - 0.8, -15.5)
            wave_deg = -132.0 + math.sin(self._wave_phase) * 26.0
            painter.rotate(wave_deg)
            painter.drawRoundedRect(QtCore.QRectF(-1.4, -0.5, 2.9, 9.2), 1.4, 1.4)
            painter.restore()
        else:
            arm_amp = 42.0 if self._running else 18.0
            arm_swing = math.sin(self._walk_phase) * arm_amp * self._walk_amount
            if torso_scale_x > 0.78:
                painter.save()
                painter.translate(-hw + 0.3, -15.5)
                painter.rotate(arm_swing)
                painter.drawRoundedRect(QtCore.QRectF(-2.2, 0.0, 2.6, 7.2), 1.2, 1.2)
                painter.restore()

                painter.save()
                painter.translate(hw - 0.3, -15.5)
                painter.rotate(-arm_swing)
                painter.drawRoundedRect(QtCore.QRectF(-0.4, 0.0, 2.6, 7.2), 1.2, 1.2)
                painter.restore()
            else:
                painter.save()
                painter.translate(dir_x * 1.4, -15.2)
                painter.rotate(-arm_swing - dir_x * (18.0 if self._running else 8.0))
                painter.drawRoundedRect(QtCore.QRectF(-1.4, 0.0, 2.8, 7.5), 1.3, 1.3)
                painter.restore()

        # --- Clean Eyeless Head (rotates/shifts gently when looking around!) ---
        painter.save()
        painter.translate(head_shift_x * 0.45, -24.2)
        painter.rotate(head_tilt)
        painter.setPen(outline)
        painter.setBrush(gold_brush)
        painter.drawEllipse(QtCore.QPointF(0.0, 0.0), 5.3, 5.3)
        painter.restore()

        painter.restore()

        # White ground dot on top of anchor ring
        painter.save()
        painter.setRenderHint(ANTIALIASING, True)
        painter.setPen(NO_PEN)
        painter.setBrush(QtGui.QBrush(QtGui.QColor("#ffffff"), BRUSH_SOLID))
        painter.drawEllipse(QtCore.QPointF(0.0, 0.0), 2.3, 2.3)
        painter.restore()


class DropTargetReticle(QgsMapCanvasItem):
    """Animated-style circular drop target shown when dragging Pegman over canvas."""

    def __init__(self, canvas: QgsMapCanvas):
        super().__init__(canvas)
        self._canvas = canvas
        self._active = False
        self._map_point: Optional[QgsPointXY] = None
        self.setZValue(115)
        self.hide()

    def set_target(self, map_point: QgsPointXY) -> None:
        self._map_point = QgsPointXY(map_point)
        self._active = True
        self.setPos(self.toCanvasCoordinates(self._map_point))
        self.show()
        self.update()

    def clear(self) -> None:
        self._active = False
        self._map_point = None
        self.hide()

    def updatePosition(self) -> None:
        if self._active and self._map_point is not None:
            self.setPos(self.toCanvasCoordinates(self._map_point))

    def boundingRect(self) -> QtCore.QRectF:
        return QtCore.QRectF(-28.0, -28.0, 56.0, 56.0)

    def paint(self, painter: QtGui.QPainter, option=None, widget=None) -> None:
        if not self._active:
            return
        painter.save()
        painter.setRenderHint(ANTIALIASING, True)
        painter.setPen(QtGui.QPen(QtGui.QColor("#38bdf8"), 2.2, PEN_DASH))
        painter.setBrush(QtGui.QBrush(QtGui.QColor(56, 189, 248, 55), BRUSH_SOLID))
        painter.drawEllipse(QtCore.QPointF(0.0, 0.0), 20.0, 20.0)
        painter.setPen(QtGui.QPen(QtGui.QColor("#facc15"), 2.0, PEN_SOLID))
        painter.setBrush(QtGui.QBrush(QtGui.QColor(250, 204, 21, 160), BRUSH_SOLID))
        painter.drawEllipse(QtCore.QPointF(0.0, 0.0), 5.0, 5.0)
        painter.restore()


class CanvasPoseOverlay(QtCore.QObject):
    """Coordinates smooth 33 FPS walk/run Pegman interpolation, grab-lift & 30s idle wave."""

    def __init__(self, canvas: QgsMapCanvas):
        super().__init__(canvas)
        self._canvas = canvas
        self._fov_band = QgsRubberBand(canvas, GEOM_POLYGON)
        self._fov_band.setFillColor(QtGui.QColor(56, 189, 248, 82))
        self._fov_band.setStrokeColor(QtGui.QColor(14, 165, 233, 210))
        self._fov_band.setWidth(2)
        self._fov_band.setZValue(110)

        self._aim_line = QgsRubberBand(canvas, GEOM_LINE)
        self._aim_line.setColor(QtGui.QColor(250, 204, 21, 235))
        self._aim_line.setWidth(3)
        self._aim_line.setLineStyle(PEN_DASH)
        self._aim_line.setZValue(112)

        self._pegman = PegmanCanvasMarker(canvas)
        self._reticle = DropTargetReticle(canvas)

        self._has_pose = False
        self._cur_lat = 0.0
        self._cur_lon = 0.0
        self._cur_heading = 0.0
        self._cur_fov = 85.0
        self._tgt_lat = 0.0
        self._tgt_lon = 0.0
        self._tgt_heading = 0.0
        self._tgt_fov = 85.0
        self._turn_vel = 0.0
        self._walk_phase = 0.0
        self._walk_amount = 0.0
        self._running = False
        self._lifted = False
        self._dangle_tilt = 0.0
        self._wave_active = False
        self._wave_phase = 0.0
        self._last_activity_ts = time.monotonic()

        self._anim_timer = QtCore.QTimer(self)
        self._anim_timer.setInterval(30)
        self._anim_timer.timeout.connect(self._on_anim_tick)

        self._idle_timer = QtCore.QTimer(self)
        self._idle_timer.setInterval(1000)
        self._idle_timer.timeout.connect(self._on_idle_check)

    def _compute_cone_radius_m(self) -> float:
        extent = self._canvas.extent()
        canvas_crs = self._canvas.mapSettings().destinationCrs()
        if canvas_crs.isGeographic():
            approx_m = extent.width() * 90000.0
        else:
            approx_m = extent.width()
        return max(22.0, min(220.0, approx_m * 0.095))

    def _shortest_angle_delta(self, current: float, target: float) -> float:
        return ((target - current + 180.0) % 360.0) - 180.0

    def hit_test_pegman(self, viewport_pt: QtCore.QPointF) -> bool:
        return self._pegman.hit_test_canvas_point(viewport_pt)

    def set_lifted_drag(self, map_pt: QgsPointXY, dangle_tilt: float = 0.0) -> None:
        """Render Pegman lifted in mid-air by its arm/collar while dragged on canvas."""
        self._anim_timer.stop()
        self._last_activity_ts = time.monotonic()
        self._wave_active = False
        self._lifted = True
        self._dangle_tilt = dangle_tilt
        self._fov_band.hide()
        self._reticle.set_target(map_pt)
        self._pegman.set_pose(
            map_pt,
            heading=self._cur_heading,
            lifted=True,
            dangle_tilt=dangle_tilt,
        )

    def _render_current_state(self) -> QgsPointXY:
        canvas_crs = self._canvas.mapSettings().destinationCrs()
        canvas_pt = wgs84_to_canvas(self._cur_lat, self._cur_lon, canvas_crs)
        if not self._lifted:
            radius_m = self._compute_cone_radius_m()
            cone_geom = build_fov_cone_polygon(
                lat=self._cur_lat,
                lon=self._cur_lon,
                heading_deg=self._cur_heading,
                fov_deg=self._cur_fov,
                radius_m=radius_m,
                canvas_crs=canvas_crs,
            )
            self._fov_band.setToGeometry(cone_geom, canvas_crs)
            self._fov_band.show()
        self._pegman.set_pose(
            canvas_pt,
            heading=self._cur_heading,
            turn_velocity=self._turn_vel,
            walk_phase=self._walk_phase,
            walk_amount=self._walk_amount,
            running=self._running,
            lifted=self._lifted,
            dangle_tilt=self._dangle_tilt,
            waving=self._wave_active,
            wave_phase=self._wave_phase,
        )
        return canvas_pt

    def update_pegman_pose(
        self,
        lat: float,
        lon: float,
        heading: float = 0.0,
        fov: float = 85.0,
        smooth: bool = True,
    ) -> QgsPointXY:
        """Set or smoothly animate Pegman (walking for near moves, running for far jumps)."""
        self._last_activity_ts = time.monotonic()
        self._wave_active = False
        self._lifted = False
        self._reticle.clear()

        heading_norm = float(heading) % 360.0
        self._tgt_lat = float(lat)
        self._tgt_lon = float(lon)
        self._tgt_heading = heading_norm
        self._tgt_fov = float(fov)

        if not self._has_pose or not smooth:
            self._has_pose = True
            self._cur_lat = self._tgt_lat
            self._cur_lon = self._tgt_lon
            self._cur_heading = self._tgt_heading
            self._cur_fov = self._tgt_fov
            self._turn_vel = 0.0
            self._walk_amount = 0.0
            self._running = False
            if not self._idle_timer.isActive():
                self._idle_timer.start()
            return self._render_current_state()

        jump_m = geodesic_distance_m(self._cur_lat, self._cur_lon, self._tgt_lat, self._tgt_lon)
        if jump_m > RUN_DISTANCE_THRESHOLD_M:
            self._running = True
        elif jump_m > 1.5:
            self._running = False

        if not self._anim_timer.isActive():
            self._anim_timer.start()
        if not self._idle_timer.isActive():
            self._idle_timer.start()
        return wgs84_to_canvas(
            self._cur_lat, self._cur_lon, self._canvas.mapSettings().destinationCrs()
        )

    def step_animation(self, dt_sec: float = 0.03) -> bool:
        """Advance one smooth interpolation frame; returns True if still animating."""
        if not self._has_pose or self._lifted:
            return False

        d_lat = self._tgt_lat - self._cur_lat
        d_lon = self._tgt_lon - self._cur_lon
        d_hdg = self._shortest_angle_delta(self._cur_heading, self._tgt_heading)
        d_fov = self._tgt_fov - self._cur_fov

        pos_dist_deg = math.hypot(d_lat, d_lon)
        moving = pos_dist_deg > 1e-6 or abs(d_hdg) > 0.25 or abs(d_fov) > 0.15

        if moving:
            rem_m = geodesic_distance_m(self._cur_lat, self._cur_lon, self._tgt_lat, self._tgt_lon)
            if rem_m > RUN_DISTANCE_THRESHOLD_M:
                self._running = True
            ease = min(1.0, max(0.16, dt_sec * (6.2 if self._running else 8.5)))
            self._cur_lat += d_lat * ease
            self._cur_lon += d_lon * ease
            self._cur_heading = (self._cur_heading + d_hdg * ease) % 360.0
            self._cur_fov += d_fov * ease

            self._turn_vel = max(-1.0, min(1.0, d_hdg / 35.0))
            if pos_dist_deg > 2e-6:
                self._walk_amount = min(1.0, max(0.35, pos_dist_deg * 18000.0))
                self._walk_phase += dt_sec * (24.0 if self._running else 12.5)
            else:
                self._walk_amount *= 0.7
            self._render_current_state()
            return True

        self._cur_lat = self._tgt_lat
        self._cur_lon = self._tgt_lon
        self._cur_heading = self._tgt_heading
        self._cur_fov = self._tgt_fov
        self._turn_vel = 0.0
        self._walk_amount = 0.0
        self._running = False

        if self._wave_active:
            self._wave_phase += dt_sec * 8.5
            self._render_current_state()
            return True

        self._render_current_state()
        return False

    def _on_anim_tick(self) -> None:
        if not self.step_animation(0.03):
            self._anim_timer.stop()

    def trigger_idle_wave_check(self, elapsed_sec: Optional[float] = None) -> bool:
        """Evaluate whether Pegman has stood idle >= 30s and should wave."""
        if not self._has_pose or self._lifted:
            return False
        idle = (
            float(elapsed_sec)
            if elapsed_sec is not None
            else (time.monotonic() - self._last_activity_ts)
        )
        if idle < IDLE_WAVE_DELAY_SEC:
            if self._wave_active:
                self._wave_active = False
                self._render_current_state()
            return False

        cycle = (idle - IDLE_WAVE_DELAY_SEC) % IDLE_WAVE_REPEAT_SEC
        should_wave = cycle <= IDLE_WAVE_DURATION_SEC
        if should_wave != self._wave_active:
            self._wave_active = should_wave
            if should_wave and not self._anim_timer.isActive():
                self._anim_timer.start()
            elif not should_wave:
                self._render_current_state()
        return self._wave_active

    def _on_idle_check(self) -> None:
        self.trigger_idle_wave_check()

    def update_drag_aim(
        self,
        origin_lat: float,
        origin_lon: float,
        origin_pt: QgsPointXY,
        aim_pt: QgsPointXY,
        heading: float,
    ) -> None:
        canvas_crs = self._canvas.mapSettings().destinationCrs()
        line_geom = QgsGeometry.fromPolylineXY([origin_pt, aim_pt])
        self._aim_line.setToGeometry(line_geom, canvas_crs)
        self._aim_line.show()
        self.update_pegman_pose(origin_lat, origin_lon, heading=heading, fov=80.0, smooth=False)

    def clear_drag_aim(self) -> None:
        self._aim_line.reset(GEOM_LINE)

    def show_drop_reticle(self, map_pt: QgsPointXY) -> None:
        self._reticle.set_target(map_pt)

    def hide_drop_reticle(self) -> None:
        self._reticle.clear()

    def clear_all(self) -> None:
        self._anim_timer.stop()
        self._idle_timer.stop()
        self._has_pose = False
        self._wave_active = False
        self._lifted = False
        self._running = False
        self._fov_band.reset(GEOM_POLYGON)
        self._aim_line.reset(GEOM_LINE)
        self._pegman.clear()
        self._reticle.clear()

    def cleanup(self) -> None:
        self.clear_all()
        scene = self._canvas.scene()
        for item in (self._fov_band, self._aim_line, self._pegman, self._reticle):
            try:
                if scene is not None and item.scene() == scene:
                    scene.removeItem(item)
            except Exception:
                pass
